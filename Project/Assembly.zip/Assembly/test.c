void main(void)
{
  int a;
  if (1+2==0.3){
    print "hello";
  }else{
    print "yuck";
  }

  a = 1;
}


