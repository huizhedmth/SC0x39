#include <stdio.h>

int main()
{
  int b;
  b = 1;
  if(0){
    int b = 2;
  }else{
    printf("%d\n", b);
  }
  return 0;
}
