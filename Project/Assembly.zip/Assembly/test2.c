int g();

double f(){return 1.0;}
int ff(){return 1;}
void fff();
int main(){
  int x, y, z;
  const int r;
  int b[3];
  /*int e = b[b[b[b[b[b[b[b[b[b[b[b[b[b[b[b[b[x+y*z%x+x&&y+!y]]]]]]]]]]]]]]]]];
  int g = b[f()];
  int h = b[0.5];*/
  if(f()){
  
  }

  if(ff());

  /*   if(fff());	*/

  /* do{}while(fff()); */

  
  /* return;
  return 1.5;
  return fff();
  return 1.5+f();
  */

  /* read x;
  read r;
  r = 1;
  x = fff();
  x = 1.5;
  x[3] = 1;
  x[1.5] = 1;
  x[1.5];
  ff(1,2,3);
  f();*/

}

void fff(){
  /*  return 1;
  return ff();
  return f();
  return;*/
}

int g(){}
